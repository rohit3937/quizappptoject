var jsonData = [
    {
        "q": "To select the contents on text box we can use?",
        "opt1": "onFocus()",
        "opt2": " onSelect",
        "opt3": "select()",
        "opt4": "focus()",
        "answer": "select()"
    },
    {
        "q": "Which of the following is not a valid XML element name?",
        "opt1": "h2",
        "opt2": " Data>",
        "opt3": " <5Ruppes>",
        "opt4": "All are invalid",
        "answer": "<5Ruppes>"
    },

    {
        "q": "If the checked attribute of checkbox is set, the property that will be true is?",
        "opt1": "checked",
        "opt2": "selected",
        "opt3": "defaultChecked",
        "opt4": "value",
        "answer": "defaultChecked"
    },

    {
        "q": "Which of the following statements is true?",
        "opt1": "All XML documents must have a schema",
        "opt2": "All elements must have  proper closing tags",
        "opt3": "All elements must be compulsorily  upper case",
        "opt4": "All the statements are true",
        "answer": "All elements must have  proper closing tags"
    },

    {
        "q": "Which property of the location object refers to an anchor located in the document?",
        "opt1": "location.host",
        "opt2": "location.protocol",
        "opt3": "location.href",
        "opt4": "location.hash",
        "answer": "location.hash"
    },

    {
        "q": "How to select the input tag  element having attribute name to apply the CSS style?",
        "opt1": "input[name]",
        "opt2": "input name",
        "opt3": "input{name}",
        "opt4": "input[name]",
        "answer": "input[name]"
    },

    {
        "q": "How to add comment in the style sheet?",
        "opt1": "<!--   comment -->",
        "opt2": "/*   comment  */",
        "opt3": " //",
        "opt4": "you can not give comment in style sheet",
        "answer": "/*   comment  */"
    },

    {
        "q": "Which of the following will correctly select the input tag Element which has the focus?",
        "opt1": "input[name]",
        "opt2": "input:focus",
        "opt3": "focus",
        "opt4": "input:autofocus",
        "answer": "input:focus"
    },

    {
        "q": "A style format can be applied to the tags by using __________.",
        "opt1": "format tag",
        "opt2": "style tag",
        "opt3": "decoration",
        "opt4": "Any of the above can be used",
        "answer": "style tag"
    },

    {
        "q": "Which of the following attribute can be used to specify image as background of an element?",
        "opt1": "background-image",
        "opt2": "background-img",
        "opt3": " image",
        "opt4": "img",
        "answer": "background-image"
    }


];