var jsonData = [
    {
        "q" : "The common element which describe the web page, is ?",
        "opt1" : "heading",
        "opt2" : "paragraph",
        "opt3": "All of these",
        "opt4":   "none of the above",
        "answer" : "All of these"
    },
    {
        "q" : "HTML stands for?",
        "opt1" : "Hyper Text Markup Language",
        "opt2" : "High Text Markup Language",
        "opt3": "Hyper Tabular Markup Language",
        "opt4": "none of the above",
        "answer" : "Hyper Text Markup Language"
    },
    {
        "q" : "which of the following tag is used to mark a begining of paragraph ?",
        "opt1" : "TD",
        "opt2" : "br",
        "opt3": "P",
        "opt4": "none of the above",
        "answer" : "P"
    },
    {
        "q" : "From which tag descriptive list starts ?",
        "opt1" : "LL",
        "opt2" : "DL",
        "opt3": "DD",
        "opt4": "none of the above",
        "answer" : "DL"
    },
    {
        "q" : "Correct HTML tag for the largest heading is _____",
        "opt1" : "h1",
        "opt2" : "h6",
        "opt3": "heading",
        "opt4": "none of the above",
        "answer" : "h1"
    },
    {
        "q": "The attribute of < form > tag",

        "opt1": "Method",
        "opt2": "Action",
        "opt3": "both opt1 & opt2",
        "opt4": "none of the above",
        "answer": "both opt1 & opt2"
    },
    {
        "q": "Markup tags tell the web browser",
        "opt1": "How to organise the page",
        "opt2": "How to display the page",
        "opt3": "How to display message box on page",
        "opt4": "None of these",
        "answer": "How to display the page"
    },
    {
        "q": "www is based on which model?",
        "opt1": "Local-server",
        "opt2": "Client-server",
        "opt3": "3-tier",
        "opt4": "None of these",
        "answer": "Client-server"
    },
    {
        "q": "What are Empty elements and is it valid ?",
        "opt1": "No, there is no such terms as Empty Element",
        "opt2": "Empty elements are element with no data",
        "opt3": "No, it is not valid to use Empty Element",
        "opt4": "None of these",
        "answer": "Empty elements are element with no data"
    },
    {
        "q": "Which of the following attributes of text box control allow to limit the maximum character?",
        "opt1": "size",
        "opt2": "len",
        "opt3": "maxlength",
        "opt4": "all of these",
        "answer": "maxlength"
    }
   
];