﻿var session = 0;
function UserLogin() {
    var userid = document.getElementById("userid").value;
    var password = document.getElementById("pwd").value;

    $.getJSON("users.json", function (data) {

        if (userid === data.UserId && password === data.Password) {
            session = 1;
            window.location.href = "index.html";
            alert("Get Started!!");
        }
        else
            alert("UserID or Password is Invalid!!");
    });

}
